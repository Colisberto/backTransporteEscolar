package br.com.transporteEscolar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransporteEscolarApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransporteEscolarApplication.class, args);
	}

}
