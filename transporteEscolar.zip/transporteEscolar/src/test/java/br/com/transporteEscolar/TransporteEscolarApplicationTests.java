package br.com.transporteEscolar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransporteEscolarApplicationTests {

	@Test
	void contextLoads() {
	}

}
